import numpy;


def differenceDeGaussiennes():


